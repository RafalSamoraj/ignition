--the query compares the results placed by users with the actual results and assigns scores
-- 5 points - the user bet on the result, including goals
-- 3 points - the user bet on the result
-- 0 points - the user bet incorrectly on the result
SELECT
    users.firstname,
    users.surname
    CASE
        WHEN --the user bet on the result, including goals
            (matchResults.team1_goalsNumber = betOnMatches.team1_goalsNumber)
            AND
            (matchResults.team2_goalsNumber = betOnMatches.team2_goalsNumber)
        THEN 5
        WHEN --the user bet on the result
            (
            (matchResults.team1_goalsNumber > matchResults.team2_goalsNumber)
            AND
            (betOnMatches.team1_goalsNumber > betOnMatches.team2_goalsNumber)
            )
            OR
            (
            (matchResults.team1_goalsNumber < matchResults.team2_goalsNumber)
            AND
            (betOnMatches.team1_goalsNumber < betOnMatches.team2_goalsNumber)
            )
            OR
            (
            (matchResults.team1_goalsNumber = matchResults.team2_goalsNumber)
            AND
            (betOnMatches.team1_goalsNumber = betOnMatches.team2_goalsNumber)
            )
        THEN 3
        ELSE 0
    END AS SCORING
INTO
    #tempTable --save to temporary table
FROM
    [betApp].[dbo].[matchResults] AS matchResults
INNER JOIN
    [betApp].[dbo].[betOnMatches] AS betOnMatches
ON
    matchResults.matchID = betOnMatches.matchID
INNER JOIN
    [betApp].[dbo].[users] AS users
ON
    users.userID = betOnMatches.userID

-- this statement sums the results from the table above
SELECT 
    firstname AS Firstname,
    surname AS Surname,
    SUM(SCORING) AS SCORING
FROM 
    #tempTable
GROUP BY
    firstname,
    surname
ORDER BY
    SCORING DESC