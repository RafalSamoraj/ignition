DECLARE @team1Goals INT;

SELECT @team1Goals = [team1_goalsNumber]
FROM [betApp].[dbo].[matchResults]
WHERE matchID = :matchID;

IF @team1Goals IS NULL
    SELECT 0
ELSE
    SELECT @team1Goals
