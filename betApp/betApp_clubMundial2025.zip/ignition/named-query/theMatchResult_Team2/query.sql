DECLARE @team2Goals INT;

SELECT @team2Goals = [team2_goalsNumber]
FROM [betApp].[dbo].[matchResults]
WHERE matchID = :matchID;

IF @team2Goals IS NULL
    SELECT 0
ELSE
    SELECT @team2Goals